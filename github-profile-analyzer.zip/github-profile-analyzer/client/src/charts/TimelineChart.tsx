import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import type { ContributionTimelineEntry } from '../types';

export default function TimelineChart({ timeline }: { timeline: ContributionTimelineEntry[] }) {
  if (timeline.length === 0) {
    return <p className="text-sm text-slate-500 dark:text-slate-400">No repository timeline data available.</p>;
  }

  return (
    <ResponsiveContainer width="100%" height={280}>
      <LineChart data={timeline} margin={{ left: -10, right: 20 }}>
        <CartesianGrid strokeDasharray="3 3" className="opacity-20" />
        <XAxis dataKey="year" tick={{ fontSize: 11 }} />
        <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
        <Tooltip />
        <Line type="monotone" dataKey="reposCreated" stroke="#22c55e" strokeWidth={2} dot={{ r: 3 }} name="Repos Created" />
      </LineChart>
    </ResponsiveContainer>
  );
}
