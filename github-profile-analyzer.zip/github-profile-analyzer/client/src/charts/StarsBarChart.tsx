import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import type { RepoSummary } from '../types';

export default function StarsBarChart({ repos }: { repos: RepoSummary[] }) {
  const data = [...repos]
    .sort((a, b) => b.stargazers_count - a.stargazers_count)
    .slice(0, 8)
    .map((r) => ({ name: r.name.length > 14 ? r.name.slice(0, 13) + '…' : r.name, stars: r.stargazers_count }));

  if (data.length === 0 || data.every((d) => d.stars === 0)) {
    return <p className="text-sm text-slate-500 dark:text-slate-400">No starred repositories yet.</p>;
  }

  return (
    <ResponsiveContainer width="100%" height={280}>
      <BarChart data={data} layout="vertical" margin={{ left: 10, right: 20 }}>
        <CartesianGrid strokeDasharray="3 3" className="opacity-20" />
        <XAxis type="number" allowDecimals={false} tick={{ fontSize: 11 }} />
        <YAxis dataKey="name" type="category" width={100} tick={{ fontSize: 11 }} />
        <Tooltip />
        <Bar dataKey="stars" fill="#6366f1" radius={[0, 6, 6, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}
