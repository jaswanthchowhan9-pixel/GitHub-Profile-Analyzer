import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import type { EventActivity } from '../types';

export default function ActivityChart({ eventActivity }: { eventActivity: EventActivity }) {
  const data = eventActivity.heatmap.slice(-30);

  if (data.length === 0) {
    return (
      <p className="text-sm text-slate-500 dark:text-slate-400">
        No recent public activity found (GitHub only exposes the last 90 days of public events).
      </p>
    );
  }

  return (
    <ResponsiveContainer width="100%" height={220}>
      <AreaChart data={data} margin={{ left: -20, right: 20 }}>
        <CartesianGrid strokeDasharray="3 3" className="opacity-20" />
        <XAxis dataKey="date" tick={{ fontSize: 10 }} tickFormatter={(d: string) => d.slice(5)} />
        <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
        <Tooltip />
        <Area type="monotone" dataKey="count" stroke="#f59e0b" fill="#f59e0b33" name="Public events" />
      </AreaChart>
    </ResponsiveContainer>
  );
}
