import axios from 'axios';
import type { Analysis, AIInsights, RepoSummary, Profile } from '../types';

const api = axios.create({
  baseURL: '/api',
  timeout: 30000,
});

export function extractErrorMessage(err: unknown): string {
  if (axios.isAxiosError(err)) {
    return err.response?.data?.error || err.message || 'Something went wrong.';
  }
  return 'Something went wrong.';
}

export async function fetchProfile(username: string): Promise<Profile> {
  const { data } = await api.get(`/github/profile/${encodeURIComponent(username)}`);
  return data;
}

export async function fetchRepos(username: string): Promise<RepoSummary[]> {
  const { data } = await api.get(`/github/repos/${encodeURIComponent(username)}`);
  return data;
}

export async function fetchAnalysis(username: string): Promise<Analysis> {
  const { data } = await api.get(`/github/analysis/${encodeURIComponent(username)}`);
  return data;
}

export async function fetchComparison(user1: string, user2: string): Promise<{ user1: Analysis; user2: Analysis }> {
  const { data } = await api.get('/github/compare', { params: { user1, user2 } });
  return data;
}

export async function fetchTrending(language = ''): Promise<any[]> {
  const { data } = await api.get('/github/trending', { params: { language } });
  return data;
}

export async function fetchAIInsights(analysis: Analysis): Promise<AIInsights> {
  const { data } = await api.post('/ai/insights', { analysis });
  return data;
}

export default api;
