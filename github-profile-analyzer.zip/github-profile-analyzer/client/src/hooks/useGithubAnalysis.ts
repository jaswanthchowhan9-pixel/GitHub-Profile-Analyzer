import { useEffect, useState, useCallback } from 'react';
import { fetchAnalysis, fetchAIInsights, extractErrorMessage } from '../services/api';
import type { Analysis, AIInsights } from '../types';
import { addSearchHistory } from '../utils/storage';

interface State {
  analysis: Analysis | null;
  insights: AIInsights | null;
  loading: boolean;
  insightsLoading: boolean;
  error: string | null;
}

export function useGithubAnalysis(username: string | undefined) {
  const [state, setState] = useState<State>({
    analysis: null,
    insights: null,
    loading: true,
    insightsLoading: false,
    error: null,
  });

  const load = useCallback(async () => {
    if (!username) return;
    setState((s) => ({ ...s, loading: true, error: null, analysis: null, insights: null }));
    try {
      const analysis = await fetchAnalysis(username);
      addSearchHistory(username);
      setState((s) => ({ ...s, analysis, loading: false }));

      setState((s) => ({ ...s, insightsLoading: true }));
      try {
        const insights = await fetchAIInsights(analysis);
        setState((s) => ({ ...s, insights, insightsLoading: false }));
      } catch {
        setState((s) => ({ ...s, insightsLoading: false }));
      }
    } catch (err) {
      setState((s) => ({ ...s, loading: false, error: extractErrorMessage(err) }));
    }
  }, [username]);

  useEffect(() => {
    load();
  }, [load]);

  return { ...state, reload: load };
}
