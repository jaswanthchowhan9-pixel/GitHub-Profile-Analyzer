const HISTORY_KEY = 'gpa_search_history';
const BOOKMARKS_KEY = 'gpa_bookmarks';
const MAX_HISTORY = 15;

export function getSearchHistory(): string[] {
  try {
    return JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]');
  } catch {
    return [];
  }
}

export function addSearchHistory(username: string): string[] {
  const current = getSearchHistory().filter((u) => u.toLowerCase() !== username.toLowerCase());
  const updated = [username, ...current].slice(0, MAX_HISTORY);
  localStorage.setItem(HISTORY_KEY, JSON.stringify(updated));
  return updated;
}

export function clearSearchHistory(): void {
  localStorage.removeItem(HISTORY_KEY);
}

export function getBookmarks(): string[] {
  try {
    return JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]');
  } catch {
    return [];
  }
}

export function toggleBookmark(username: string): string[] {
  const current = getBookmarks();
  const exists = current.some((u) => u.toLowerCase() === username.toLowerCase());
  const updated = exists
    ? current.filter((u) => u.toLowerCase() !== username.toLowerCase())
    : [...current, username];
  localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(updated));
  return updated;
}

export function isBookmarked(username: string): boolean {
  return getBookmarks().some((u) => u.toLowerCase() === username.toLowerCase());
}
