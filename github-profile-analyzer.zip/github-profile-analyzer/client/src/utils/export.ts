import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import type { Analysis, AIInsights } from '../types';

export function downloadJSON(analysis: Analysis, insights: AIInsights | null): void {
  const payload = { analysis, aiInsights: insights, exportedAt: new Date().toISOString() };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${analysis.profile.username}-github-analysis.json`;
  link.click();
  URL.revokeObjectURL(url);
}

// Renders the given DOM element (the dashboard) into a multi-page PDF.
export async function downloadPDFFromElement(elementId: string, filename: string): Promise<void> {
  const element = document.getElementById(elementId);
  if (!element) throw new Error('Dashboard element not found for export.');

  const canvas = await html2canvas(element, {
    scale: 2,
    backgroundColor: getComputedStyle(document.body).backgroundColor || '#ffffff',
    useCORS: true,
  });

  const imgData = canvas.toDataURL('image/png');
  const pdf = new jsPDF('p', 'mm', 'a4');
  const pageWidth = pdf.internal.pageSize.getWidth();
  const pageHeight = pdf.internal.pageSize.getHeight();

  const imgWidth = pageWidth;
  const imgHeight = (canvas.height * imgWidth) / canvas.width;

  let heightLeft = imgHeight;
  let position = 0;

  pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
  heightLeft -= pageHeight;

  while (heightLeft > 0) {
    position = heightLeft - imgHeight;
    pdf.addPage();
    pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
    heightLeft -= pageHeight;
  }

  pdf.save(filename);
}

export function buildShareableLink(username: string): string {
  const url = new URL(window.location.href);
  url.pathname = `/dashboard/${username}`;
  url.search = '';
  return url.toString();
}
