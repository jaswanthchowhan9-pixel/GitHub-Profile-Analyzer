import { useState } from 'react';
import { Download, FileJson, FileText, Share2, Check } from 'lucide-react';
import type { Analysis, AIInsights } from '../types';
import { downloadJSON, downloadPDFFromElement, buildShareableLink } from '../utils/export';

export default function ExportButtons({ analysis, insights }: { analysis: Analysis; insights: AIInsights | null }) {
  const [exportingPdf, setExportingPdf] = useState(false);
  const [copied, setCopied] = useState(false);

  const handlePdf = async () => {
    setExportingPdf(true);
    try {
      await downloadPDFFromElement('dashboard-content', `${analysis.profile.username}-github-report.pdf`);
    } catch (err) {
      console.error(err);
      alert('Could not generate PDF. Please try again.');
    } finally {
      setExportingPdf(false);
    }
  };

  const handleShare = async () => {
    const link = buildShareableLink(analysis.profile.username);
    await navigator.clipboard.writeText(link);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex flex-wrap gap-2">
      <button onClick={() => downloadJSON(analysis, insights)} className="btn-secondary">
        <FileJson className="w-4 h-4" /> Export JSON
      </button>
      <button onClick={handlePdf} disabled={exportingPdf} className="btn-secondary">
        <FileText className="w-4 h-4" /> {exportingPdf ? 'Generating…' : 'Download PDF'}
      </button>
      <button onClick={handleShare} className="btn-secondary">
        {copied ? <Check className="w-4 h-4 text-green-500" /> : <Share2 className="w-4 h-4" />}
        {copied ? 'Link copied!' : 'Share'}
      </button>
    </div>
  );
}
