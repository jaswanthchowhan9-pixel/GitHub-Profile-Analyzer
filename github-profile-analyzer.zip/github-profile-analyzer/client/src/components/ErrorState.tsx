import { AlertTriangle } from 'lucide-react';

export default function ErrorState({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-24 text-center px-4">
      <AlertTriangle className="w-10 h-10 text-amber-500" />
      <p className="text-slate-700 dark:text-slate-300 max-w-md">{message}</p>
      {onRetry && (
        <button
          onClick={onRetry}
          className="mt-2 px-4 py-2 rounded-lg bg-brand-600 hover:bg-brand-700 text-white text-sm font-medium"
        >
          Try again
        </button>
      )}
    </div>
  );
}
