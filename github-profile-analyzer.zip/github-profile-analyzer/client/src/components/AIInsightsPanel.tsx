import { Sparkles, GraduationCap, Rocket, Briefcase, FileText } from 'lucide-react';
import type { AIInsights } from '../types';

export default function AIInsightsPanel({ insights, loading }: { insights: AIInsights | null; loading: boolean }) {
  if (loading) {
    return (
      <div className="card p-6 flex items-center gap-3">
        <div className="w-5 h-5 border-2 border-brand-200 border-t-brand-600 rounded-full animate-spin" />
        <p className="text-sm text-slate-500 dark:text-slate-400">Generating AI insights…</p>
      </div>
    );
  }

  if (!insights) {
    return (
      <div className="card p-6">
        <p className="text-sm text-slate-500 dark:text-slate-400">AI insights are unavailable right now.</p>
      </div>
    );
  }

  return (
    <div className="card p-6 space-y-5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 font-semibold text-brand-600 dark:text-brand-400">
          <Sparkles className="w-4 h-4" />
          AI Developer Insights
        </div>
        <span className="text-[11px] px-2 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400">
          {insights.source === 'rule-based' ? 'Rule-based (no AI key configured)' : `Generated via ${insights.source}`}
        </span>
      </div>

      <p className="text-sm text-slate-700 dark:text-slate-300">{insights.skillSummary}</p>

      <div>
        <p className="text-xs font-semibold uppercase text-slate-400 mb-2">Strongest Technologies</p>
        <div className="flex flex-wrap gap-2">
          {insights.strongestTechnologies.map((t) => (
            <span key={t} className="px-2.5 py-1 rounded-full text-xs bg-brand-50 dark:bg-brand-900/40 text-brand-700 dark:text-brand-300">
              {t}
            </span>
          ))}
        </div>
      </div>

      <InsightList icon={<GraduationCap className="w-4 h-4" />} title="Learning Recommendations" items={insights.learningRecommendations} />
      <InsightList icon={<Rocket className="w-4 h-4" />} title="Recommended Projects" items={insights.recommendedProjects} />
      <InsightList icon={<Briefcase className="w-4 h-4" />} title="Career Recommendations" items={insights.careerRecommendations} />

      <div>
        <p className="text-xs font-semibold uppercase text-slate-400 mb-2 flex items-center gap-1.5">
          <FileText className="w-3.5 h-3.5" /> Resume-Ready Summary
        </p>
        <p className="text-sm italic text-slate-600 dark:text-slate-300 border-l-2 border-brand-500 pl-3">
          {insights.resumeSummary}
        </p>
      </div>
    </div>
  );
}

function InsightList({ icon, title, items }: { icon: React.ReactNode; title: string; items: string[] }) {
  return (
    <div>
      <p className="text-xs font-semibold uppercase text-slate-400 mb-2 flex items-center gap-1.5">
        {icon} {title}
      </p>
      <ul className="space-y-1.5">
        {items.map((item, i) => (
          <li key={i} className="text-sm text-slate-700 dark:text-slate-300 flex gap-2">
            <span className="text-brand-500 mt-1">•</span>
            <span>{item}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
