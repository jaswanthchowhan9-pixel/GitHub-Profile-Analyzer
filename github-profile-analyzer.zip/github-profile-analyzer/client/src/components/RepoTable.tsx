import { useMemo, useState } from 'react';
import { Star, GitFork, ExternalLink, Search } from 'lucide-react';
import type { RepoSummary, SortKey } from '../types';
import { timeAgo } from '../utils/format';

export default function RepoTable({ repos }: { repos: RepoSummary[] }) {
  const [query, setQuery] = useState('');
  const [language, setLanguage] = useState('all');
  const [sortKey, setSortKey] = useState<SortKey>('stars');

  const languages = useMemo(() => {
    const set = new Set<string>();
    repos.forEach((r) => r.language && set.add(r.language));
    return ['all', ...Array.from(set).sort()];
  }, [repos]);

  const filtered = useMemo(() => {
    let result = repos.filter((r) => !r.fork);
    if (query.trim()) {
      const q = query.toLowerCase();
      result = result.filter((r) => r.name.toLowerCase().includes(q) || (r.description || '').toLowerCase().includes(q));
    }
    if (language !== 'all') {
      result = result.filter((r) => r.language === language);
    }
    const sorted = [...result];
    switch (sortKey) {
      case 'stars':
        sorted.sort((a, b) => b.stargazers_count - a.stargazers_count);
        break;
      case 'forks':
        sorted.sort((a, b) => b.forks_count - a.forks_count);
        break;
      case 'updated':
        sorted.sort((a, b) => new Date(b.pushed_at).getTime() - new Date(a.pushed_at).getTime());
        break;
      case 'name':
        sorted.sort((a, b) => a.name.localeCompare(b.name));
        break;
    }
    return sorted;
  }, [repos, query, language, sortKey]);

  return (
    <div className="card p-5">
      <div className="flex flex-col sm:flex-row gap-3 mb-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search repositories…"
            className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
          />
        </div>
        <select
          value={language}
          onChange={(e) => setLanguage(e.target.value)}
          className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-sm"
        >
          {languages.map((l) => (
            <option key={l} value={l}>
              {l === 'all' ? 'All languages' : l}
            </option>
          ))}
        </select>
        <select
          value={sortKey}
          onChange={(e) => setSortKey(e.target.value as SortKey)}
          className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-sm"
        >
          <option value="stars">Sort: Most stars</option>
          <option value="forks">Sort: Most forks</option>
          <option value="updated">Sort: Recently updated</option>
          <option value="name">Sort: Name (A-Z)</option>
        </select>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
              <th className="py-2 pr-4">Repository</th>
              <th className="py-2 pr-4">Language</th>
              <th className="py-2 pr-4">Stars</th>
              <th className="py-2 pr-4">Forks</th>
              <th className="py-2 pr-4">Updated</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((r) => (
              <tr key={r.full_name} className="border-b border-slate-100 dark:border-slate-900 hover:bg-slate-50 dark:hover:bg-slate-900/50">
                <td className="py-3 pr-4">
                  <a href={r.html_url} target="_blank" rel="noreferrer" className="font-medium text-brand-600 dark:text-brand-400 flex items-center gap-1">
                    {r.name} <ExternalLink className="w-3 h-3" />
                  </a>
                  {r.description && <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-1 max-w-sm">{r.description}</p>}
                </td>
                <td className="py-3 pr-4">{r.language || '—'}</td>
                <td className="py-3 pr-4">
                  <span className="flex items-center gap-1">
                    <Star className="w-3.5 h-3.5 text-amber-500" /> {r.stargazers_count}
                  </span>
                </td>
                <td className="py-3 pr-4">
                  <span className="flex items-center gap-1">
                    <GitFork className="w-3.5 h-3.5" /> {r.forks_count}
                  </span>
                </td>
                <td className="py-3 pr-4 text-slate-500 dark:text-slate-400">{timeAgo(r.pushed_at)}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length === 0 && (
          <p className="text-center text-sm text-slate-500 dark:text-slate-400 py-8">No repositories match your filters.</p>
        )}
      </div>
    </div>
  );
}
