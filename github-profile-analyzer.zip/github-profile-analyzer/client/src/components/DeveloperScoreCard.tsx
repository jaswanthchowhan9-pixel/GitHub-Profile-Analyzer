import { Award } from 'lucide-react';

export default function DeveloperScoreCard({ score, level }: { score: number; level: string }) {
  const color = score >= 75 ? '#22c55e' : score >= 50 ? '#6366f1' : score >= 25 ? '#f59e0b' : '#ef4444';
  const circumference = 2 * Math.PI * 42;
  const offset = circumference - (score / 100) * circumference;

  return (
    <div className="card p-6 flex items-center gap-6">
      <div className="relative w-28 h-28 shrink-0">
        <svg viewBox="0 0 100 100" className="w-28 h-28 -rotate-90">
          <circle cx="50" cy="50" r="42" fill="none" stroke="currentColor" strokeWidth="8" className="text-slate-200 dark:text-slate-800" />
          <circle
            cx="50"
            cy="50"
            r="42"
            fill="none"
            stroke={color}
            strokeWidth="8"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            strokeLinecap="round"
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-2xl font-bold">{score}</span>
          <span className="text-[10px] text-slate-500 dark:text-slate-400">/ 100</span>
        </div>
      </div>
      <div>
        <div className="flex items-center gap-2 text-brand-600 dark:text-brand-400 font-semibold">
          <Award className="w-4 h-4" />
          Developer Score
        </div>
        <p className="mt-1 text-lg font-bold">{level}</p>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 max-w-xs">
          Calculated from followers, stars earned, repo output, language diversity, and recent activity.
        </p>
      </div>
    </div>
  );
}
