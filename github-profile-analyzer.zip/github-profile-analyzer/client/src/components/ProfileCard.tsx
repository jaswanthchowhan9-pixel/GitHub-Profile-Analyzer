import { MapPin, Building2, Link as LinkIcon, Calendar, Bookmark, BookmarkCheck, Users } from 'lucide-react';
import type { Profile } from '../types';
import { formatDate, formatNumber } from '../utils/format';

interface Props {
  profile: Profile;
  bookmarked: boolean;
  onToggleBookmark: () => void;
}

export default function ProfileCard({ profile, bookmarked, onToggleBookmark }: Props) {
  return (
    <div className="card p-6 flex flex-col sm:flex-row gap-6 items-start">
      <img
        src={profile.avatar_url}
        alt={profile.username}
        className="w-24 h-24 rounded-2xl border border-slate-200 dark:border-slate-800"
      />
      <div className="flex-1 min-w-0">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h1 className="text-2xl font-bold">{profile.name || profile.username}</h1>
            <a
              href={profile.html_url}
              target="_blank"
              rel="noreferrer"
              className="text-brand-600 dark:text-brand-400 text-sm font-medium"
            >
              @{profile.username}
            </a>
          </div>
          <button
            onClick={onToggleBookmark}
            aria-label="Bookmark profile"
            className="p-2 rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 shrink-0"
          >
            {bookmarked ? (
              <BookmarkCheck className="w-4 h-4 text-brand-600 dark:text-brand-400" />
            ) : (
              <Bookmark className="w-4 h-4" />
            )}
          </button>
        </div>

        {profile.bio && <p className="mt-2 text-slate-600 dark:text-slate-300">{profile.bio}</p>}

        <div className="mt-4 flex flex-wrap gap-x-5 gap-y-2 text-sm text-slate-500 dark:text-slate-400">
          {profile.company && (
            <span className="flex items-center gap-1.5">
              <Building2 className="w-4 h-4" /> {profile.company}
            </span>
          )}
          {profile.location && (
            <span className="flex items-center gap-1.5">
              <MapPin className="w-4 h-4" /> {profile.location}
            </span>
          )}
          {profile.blog && (
            <a
              href={profile.blog.startsWith('http') ? profile.blog : `https://${profile.blog}`}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-1.5 hover:text-brand-600"
            >
              <LinkIcon className="w-4 h-4" /> {profile.blog}
            </a>
          )}
          <span className="flex items-center gap-1.5">
            <Calendar className="w-4 h-4" /> Joined {formatDate(profile.created_at)}
          </span>
        </div>

        <div className="mt-4 flex flex-wrap gap-4">
          <Stat label="Followers" value={formatNumber(profile.followers)} icon={<Users className="w-4 h-4" />} />
          <Stat label="Following" value={formatNumber(profile.following)} />
          <Stat label="Public repos" value={formatNumber(profile.public_repos)} />
          <Stat label="Gists" value={formatNumber(profile.public_gists)} />
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value, icon }: { label: string; value: string; icon?: React.ReactNode }) {
  return (
    <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800/60">
      {icon}
      <div>
        <p className="text-sm font-semibold leading-none">{value}</p>
        <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">{label}</p>
      </div>
    </div>
  );
}
