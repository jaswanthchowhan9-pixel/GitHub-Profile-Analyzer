import { Star, GitFork, AlertCircle, Eye, HardDrive, FolderGit2 } from 'lucide-react';
import type { RepoStats } from '../types';
import { formatNumber } from '../utils/format';

export default function StatsGrid({ stats }: { stats: RepoStats }) {
  const items = [
    { label: 'Total Repos', value: stats.totalRepos, icon: FolderGit2 },
    { label: 'Total Stars', value: stats.totalStars, icon: Star },
    { label: 'Total Forks', value: stats.totalForks, icon: GitFork },
    { label: 'Open Issues', value: stats.totalOpenIssues, icon: AlertCircle },
    { label: 'Watchers', value: stats.totalWatchers, icon: Eye },
    { label: 'Total Size (KB)', value: stats.totalSizeKb, icon: HardDrive },
  ];

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
      {items.map(({ label, value, icon: Icon }) => (
        <div key={label} className="card p-4 flex flex-col items-start gap-2">
          <Icon className="w-4 h-4 text-brand-600 dark:text-brand-400" />
          <p className="text-xl font-bold">{formatNumber(value)}</p>
          <p className="text-xs text-slate-500 dark:text-slate-400">{label}</p>
        </div>
      ))}
    </div>
  );
}
