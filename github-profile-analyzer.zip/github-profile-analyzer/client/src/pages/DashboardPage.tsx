import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { useGithubAnalysis } from '../hooks/useGithubAnalysis';
import Loader from '../components/Loader';
import ErrorState from '../components/ErrorState';
import ProfileCard from '../components/ProfileCard';
import StatsGrid from '../components/StatsGrid';
import DeveloperScoreCard from '../components/DeveloperScoreCard';
import LanguagePieChart from '../charts/LanguagePieChart';
import StarsBarChart from '../charts/StarsBarChart';
import TimelineChart from '../charts/TimelineChart';
import ActivityChart from '../charts/ActivityChart';
import RepoTable from '../components/RepoTable';
import AIInsightsPanel from '../components/AIInsightsPanel';
import ExportButtons from '../components/ExportButtons';
import SearchBar from '../components/SearchBar';
import { isBookmarked, toggleBookmark } from '../utils/storage';

export default function DashboardPage() {
  const { username } = useParams<{ username: string }>();
  const navigate = useNavigate();
  const { analysis, insights, loading, insightsLoading, error, reload } = useGithubAnalysis(username);
  const [bookmarked, setBookmarked] = useState(false);

  useEffect(() => {
    if (username) setBookmarked(isBookmarked(username));
  }, [username]);

  const handleToggleBookmark = () => {
    if (!username) return;
    toggleBookmark(username);
    setBookmarked((b) => !b);
  };

  if (loading) return <Loader label={`Analyzing @${username}…`} />;
  if (error) return <ErrorState message={error} onRetry={reload} />;
  if (!analysis) return null;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center gap-3 justify-between">
        <button
          onClick={() => navigate('/')}
          className="flex items-center gap-1.5 text-sm text-slate-500 hover:text-brand-600 dark:hover:text-brand-400 w-fit"
        >
          <ArrowLeft className="w-4 h-4" /> Back to search
        </button>
        <div className="w-full sm:max-w-sm">
          <SearchBar onSearch={(u) => navigate(`/dashboard/${u}`)} placeholder="Analyze another username…" />
        </div>
      </div>

      <div id="dashboard-content" className="space-y-6">
        <ProfileCard profile={analysis.profile} bookmarked={bookmarked} onToggleBookmark={handleToggleBookmark} />

        <div className="grid lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2">
            <StatsGrid stats={analysis.repoStats} />
          </div>
          <DeveloperScoreCard score={analysis.developerScore} level={analysis.experienceLevel} />
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          <div className="card p-5">
            <h3 className="font-semibold mb-3">Language Distribution</h3>
            <LanguagePieChart data={analysis.languageStats.distribution} />
          </div>
          <div className="card p-5">
            <h3 className="font-semibold mb-3">Most Starred Repositories</h3>
            <StarsBarChart repos={analysis.repos} />
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          <div className="card p-5">
            <h3 className="font-semibold mb-3">Repository Creation Timeline</h3>
            <TimelineChart timeline={analysis.contribution.timeline} />
          </div>
          <div className="card p-5">
            <h3 className="font-semibold mb-3">Recent Public Activity</h3>
            <ActivityChart eventActivity={analysis.eventActivity} />
          </div>
        </div>

        <AIInsightsPanel insights={insights} loading={insightsLoading} />

        <div>
          <h3 className="font-semibold mb-3">Repositories</h3>
          <RepoTable repos={analysis.repos} />
        </div>
      </div>

      <ExportButtons analysis={analysis} insights={insights} />
    </div>
  );
}
