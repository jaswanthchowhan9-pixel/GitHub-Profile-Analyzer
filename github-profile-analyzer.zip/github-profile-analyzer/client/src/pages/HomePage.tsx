import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Clock, Bookmark, TrendingUp, Github } from 'lucide-react';
import SearchBar from '../components/SearchBar';
import { getSearchHistory, getBookmarks } from '../utils/storage';
import { fetchTrending } from '../services/api';

export default function HomePage() {
  const navigate = useNavigate();
  const [history, setHistory] = useState<string[]>([]);
  const [bookmarks, setBookmarks] = useState<string[]>([]);
  const [trending, setTrending] = useState<any[]>([]);

  useEffect(() => {
    setHistory(getSearchHistory());
    setBookmarks(getBookmarks());
    fetchTrending().then(setTrending).catch(() => setTrending([]));
  }, []);

  const goTo = (username: string) => navigate(`/dashboard/${username}`);

  return (
    <div className="max-w-3xl mx-auto pt-10 sm:pt-16">
      <div className="text-center mb-10">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-50 dark:bg-brand-900/30 text-brand-700 dark:text-brand-300 text-xs font-medium mb-4">
          <Github className="w-3.5 h-3.5" /> AI-powered GitHub analytics
        </div>
        <h1 className="text-3xl sm:text-4xl font-bold tracking-tight">GitHub Profile Analyzer</h1>
        <p className="mt-3 text-slate-500 dark:text-slate-400">
          Enter any GitHub username to get a full dashboard: language breakdown, repo stats, contribution trends,
          developer score, and AI-generated career insights.
        </p>
      </div>

      <SearchBar onSearch={goTo} />

      {(history.length > 0 || bookmarks.length > 0) && (
        <div className="grid sm:grid-cols-2 gap-4 mt-8">
          {history.length > 0 && (
            <div className="card p-4">
              <p className="flex items-center gap-1.5 text-xs font-semibold uppercase text-slate-400 mb-3">
                <Clock className="w-3.5 h-3.5" /> Recent Searches
              </p>
              <div className="flex flex-wrap gap-2">
                {history.map((u) => (
                  <button key={u} onClick={() => goTo(u)} className="px-3 py-1.5 rounded-full text-sm bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700">
                    {u}
                  </button>
                ))}
              </div>
            </div>
          )}
          {bookmarks.length > 0 && (
            <div className="card p-4">
              <p className="flex items-center gap-1.5 text-xs font-semibold uppercase text-slate-400 mb-3">
                <Bookmark className="w-3.5 h-3.5" /> Bookmarked Profiles
              </p>
              <div className="flex flex-wrap gap-2">
                {bookmarks.map((u) => (
                  <button key={u} onClick={() => goTo(u)} className="px-3 py-1.5 rounded-full text-sm bg-brand-50 dark:bg-brand-900/30 text-brand-700 dark:text-brand-300 hover:opacity-80">
                    {u}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {trending.length > 0 && (
        <div className="card p-4 mt-4">
          <p className="flex items-center gap-1.5 text-xs font-semibold uppercase text-slate-400 mb-3">
            <TrendingUp className="w-3.5 h-3.5" /> Trending This Week
          </p>
          <div className="space-y-2">
            {trending.slice(0, 6).map((repo) => (
              <a
                key={repo.id}
                href={repo.html_url}
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-between text-sm py-1.5 border-b border-slate-100 dark:border-slate-900 last:border-0 hover:text-brand-600"
              >
                <span className="truncate">{repo.full_name}</span>
                <span className="text-slate-400 shrink-0 ml-3">★ {repo.stargazers_count}</span>
              </a>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
