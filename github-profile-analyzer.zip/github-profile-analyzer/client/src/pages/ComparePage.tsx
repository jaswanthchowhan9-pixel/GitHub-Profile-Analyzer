import { useState, FormEvent } from 'react';
import { GitCompare, Star, Users, FolderGit2, Award } from 'lucide-react';
import { fetchComparison, extractErrorMessage } from '../services/api';
import type { Analysis } from '../types';
import Loader from '../components/Loader';
import ErrorState from '../components/ErrorState';
import { formatNumber } from '../utils/format';

export default function ComparePage() {
  const [user1, setUser1] = useState('');
  const [user2, setUser2] = useState('');
  const [data, setData] = useState<{ user1: Analysis; user2: Analysis } | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!user1.trim() || !user2.trim()) return;
    setLoading(true);
    setError(null);
    setData(null);
    try {
      const result = await fetchComparison(user1.trim(), user2.trim());
      setData(result);
    } catch (err) {
      setError(extractErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-50 dark:bg-brand-900/30 text-brand-700 dark:text-brand-300 text-xs font-medium mb-4">
          <GitCompare className="w-3.5 h-3.5" /> Head-to-head comparison
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold">Compare GitHub Profiles</h1>
      </div>

      <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row items-center gap-3 mb-8">
        <input
          value={user1}
          onChange={(e) => setUser1(e.target.value)}
          placeholder="First username"
          className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 focus:outline-none focus:ring-2 focus:ring-brand-500"
        />
        <span className="text-slate-400 font-medium">vs</span>
        <input
          value={user2}
          onChange={(e) => setUser2(e.target.value)}
          placeholder="Second username"
          className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 focus:outline-none focus:ring-2 focus:ring-brand-500"
        />
        <button type="submit" disabled={loading} className="btn-primary px-6 py-3 shrink-0">
          {loading ? 'Comparing…' : 'Compare'}
        </button>
      </form>

      {loading && <Loader label="Comparing profiles…" />}
      {error && <ErrorState message={error} />}

      {data && (
        <div className="grid sm:grid-cols-2 gap-4">
          <CompareCard analysis={data.user1} highlight={data.user1.developerScore >= data.user2.developerScore} />
          <CompareCard analysis={data.user2} highlight={data.user2.developerScore > data.user1.developerScore} />
        </div>
      )}
    </div>
  );
}

function CompareCard({ analysis, highlight }: { analysis: Analysis; highlight: boolean }) {
  const { profile, repoStats, developerScore, experienceLevel, languageStats } = analysis;
  return (
    <div className={`card p-5 ${highlight ? 'ring-2 ring-brand-500' : ''}`}>
      <div className="flex items-center gap-3">
        <img src={profile.avatar_url} alt={profile.username} className="w-14 h-14 rounded-xl" />
        <div>
          <p className="font-semibold">{profile.name || profile.username}</p>
          <p className="text-sm text-slate-500">@{profile.username}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2 mt-4 text-sm">
        <Metric icon={<Award className="w-3.5 h-3.5" />} label="Dev Score" value={`${developerScore}/100`} />
        <Metric icon={<FolderGit2 className="w-3.5 h-3.5" />} label="Repos" value={formatNumber(repoStats.totalRepos)} />
        <Metric icon={<Star className="w-3.5 h-3.5" />} label="Stars" value={formatNumber(repoStats.totalStars)} />
        <Metric icon={<Users className="w-3.5 h-3.5" />} label="Followers" value={formatNumber(profile.followers)} />
      </div>

      <div className="mt-4 text-sm">
        <p className="text-slate-500">Experience Level</p>
        <p className="font-medium">{experienceLevel}</p>
      </div>

      <div className="mt-3 text-sm">
        <p className="text-slate-500">Primary Language</p>
        <p className="font-medium">{languageStats.primaryLanguage}</p>
      </div>
    </div>
  );
}

function Metric({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="flex items-center gap-2 px-2.5 py-2 rounded-lg bg-slate-100 dark:bg-slate-800/60">
      {icon}
      <div>
        <p className="font-semibold leading-none">{value}</p>
        <p className="text-[10px] text-slate-500 mt-0.5">{label}</p>
      </div>
    </div>
  );
}
