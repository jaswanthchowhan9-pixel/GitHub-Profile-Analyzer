import { Link } from 'react-router-dom';

export default function NotFoundPage() {
  return (
    <div className="text-center py-24">
      <h1 className="text-3xl font-bold">404</h1>
      <p className="text-slate-500 mt-2">Page not found.</p>
      <Link to="/" className="text-brand-600 dark:text-brand-400 mt-4 inline-block font-medium">
        Go home
      </Link>
    </div>
  );
}
