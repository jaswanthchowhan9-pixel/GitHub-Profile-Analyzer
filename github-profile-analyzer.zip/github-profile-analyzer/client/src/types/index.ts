export interface Profile {
  username: string;
  name: string | null;
  avatar_url: string;
  bio: string | null;
  company: string | null;
  location: string | null;
  blog: string | null;
  twitter_username: string | null;
  email: string | null;
  followers: number;
  following: number;
  public_repos: number;
  public_gists: number;
  created_at: string;
  html_url: string;
  hireable: boolean | null;
}

export interface RepoSummary {
  name: string;
  full_name: string;
  description: string | null;
  html_url: string;
  stargazers_count: number;
  forks_count: number;
  language: string | null;
  open_issues_count: number;
  watchers_count: number;
  size: number;
  topics: string[];
  created_at: string;
  updated_at: string;
  pushed_at: string;
  fork: boolean;
  license: string | null;
  archived: boolean;
  default_branch: string;
}

export interface LanguageEntry {
  language: string;
  bytes: number;
  percentage: number;
}

export interface LanguageStats {
  distribution: LanguageEntry[];
  primaryLanguage: string;
  totalLanguages: number;
}

export interface RepoStats {
  totalRepos: number;
  originalRepos: number;
  forkedRepos: number;
  totalStars: number;
  totalForks: number;
  totalOpenIssues: number;
  totalWatchers: number;
  totalSizeKb: number;
  mostStarred: RepoSummary | null;
  mostForked: RepoSummary | null;
  topics: string[];
  licenses: Record<string, number>;
}

export interface ContributionTimelineEntry {
  year: number;
  reposCreated: number;
}

export interface Contribution {
  timeline: ContributionTimelineEntry[];
  recentlyActiveRepos: number;
}

export interface EventActivity {
  typeCounts: Record<string, number>;
  heatmap: { date: string; count: number }[];
  totalPublicEvents: number;
}

export interface RepoHealth {
  average: number;
  top: { name: string; healthScore: number }[];
}

export interface Analysis {
  profile: Profile;
  repoStats: RepoStats;
  languageStats: LanguageStats;
  contribution: Contribution;
  eventActivity: EventActivity;
  repoHealth: RepoHealth;
  developerScore: number;
  experienceLevel: string;
  repos: RepoSummary[];
}

export interface AIInsights {
  skillSummary: string;
  experienceLevel: string;
  strongestTechnologies: string[];
  learningRecommendations: string[];
  recommendedProjects: string[];
  resumeSummary: string;
  careerRecommendations: string[];
  source: 'openai' | 'gemini' | 'rule-based';
}

export type SortKey = 'stars' | 'forks' | 'updated' | 'name';
