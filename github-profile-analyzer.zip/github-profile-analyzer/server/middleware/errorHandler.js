function errorHandler(err, req, res, next) {
  console.error(err.message);

  if (err.response) {
    // Axios error from GitHub / AI provider
    const status = err.response.status || 500;
    const ghMessage = err.response.data && err.response.data.message;

    if (status === 404) {
      return res.status(404).json({ error: 'GitHub user or resource not found.' });
    }
    if (status === 403 || status === 429) {
      return res.status(429).json({
        error: 'GitHub API rate limit exceeded. Add a GITHUB_TOKEN in server/.env to raise the limit.',
        details: ghMessage,
      });
    }
    return res.status(status).json({ error: ghMessage || 'Upstream API error.' });
  }

  res.status(err.status || 500).json({ error: err.message || 'Internal server error.' });
}

module.exports = errorHandler;
