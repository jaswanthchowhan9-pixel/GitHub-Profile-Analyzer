const axios = require('axios');

function buildPrompt(analysis) {
  const { profile, repoStats, languageStats, developerScore, experienceLevel, repos } = analysis;

  const topRepoNames = [...repos]
    .sort((a, b) => b.stargazers_count - a.stargazers_count)
    .slice(0, 5)
    .map((r) => `${r.name} (${r.stargazers_count}★, ${r.language || 'N/A'})`)
    .join(', ');

  const topLanguages = languageStats.distribution
    .slice(0, 6)
    .map((l) => `${l.language} ${l.percentage}%`)
    .join(', ');

  return `You are a technical recruiter and senior engineering mentor analyzing a GitHub profile.

Profile: ${profile.name || profile.username} (@${profile.username})
Bio: ${profile.bio || 'N/A'}
Location: ${profile.location || 'N/A'}
Followers: ${profile.followers}, Following: ${profile.following}
Public repos: ${profile.public_repos}
Account created: ${profile.created_at}
Total stars earned: ${repoStats.totalStars}
Primary language: ${languageStats.primaryLanguage}
Language breakdown: ${topLanguages}
Top repositories: ${topRepoNames}
Computed developer score (0-100): ${developerScore}
Computed experience level: ${experienceLevel}

Return ONLY valid JSON (no markdown, no code fences) matching exactly this shape:
{
  "skillSummary": "2-3 sentence summary of the developer's overall skill profile",
  "experienceLevel": "one of Beginner, Junior / Growing, Intermediate, Senior / Advanced",
  "strongestTechnologies": ["tech1", "tech2", "tech3"],
  "learningRecommendations": ["suggestion1", "suggestion2", "suggestion3"],
  "recommendedProjects": ["project idea 1", "project idea 2", "project idea 3"],
  "resumeSummary": "a polished 2-3 sentence resume-ready professional summary written in third person",
  "careerRecommendations": ["career suggestion 1", "career suggestion 2"]
}`;
}

function extractJson(text) {
  const cleaned = text.replace(/```json/gi, '').replace(/```/g, '').trim();
  const start = cleaned.indexOf('{');
  const end = cleaned.lastIndexOf('}');
  if (start === -1 || end === -1) throw new Error('No JSON found in AI response');
  return JSON.parse(cleaned.slice(start, end + 1));
}

async function callOpenAI(prompt) {
  const { data } = await axios.post(
    'https://api.openai.com/v1/chat/completions',
    {
      model: process.env.OPENAI_MODEL || 'gpt-4o-mini',
      messages: [{ role: 'user', content: prompt }],
      temperature: 0.6,
    },
    {
      headers: {
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
        'Content-Type': 'application/json',
      },
      timeout: 30000,
    }
  );
  return extractJson(data.choices[0].message.content);
}

async function callGemini(prompt) {
  const model = process.env.GEMINI_MODEL || 'gemini-1.5-flash';
  const { data } = await axios.post(
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${process.env.GEMINI_API_KEY}`,
    { contents: [{ parts: [{ text: prompt }] }] },
    { headers: { 'Content-Type': 'application/json' }, timeout: 30000 }
  );
  return extractJson(data.candidates[0].content.parts[0].text);
}

// Deterministic rule-based fallback so the app fully works with zero AI API keys
function generateFallbackInsights(analysis) {
  const { languageStats, repoStats, developerScore, experienceLevel, profile } = analysis;
  const top = languageStats.distribution.slice(0, 3).map((l) => l.language);

  return {
    skillSummary: `${profile.name || profile.username} has published ${repoStats.originalRepos} original repositories primarily using ${languageStats.primaryLanguage}, earning ${repoStats.totalStars} stars across their work. This reflects a developer score of ${developerScore}/100, placing them at the "${experienceLevel}" level.`,
    experienceLevel,
    strongestTechnologies: top.length ? top : ['General Programming'],
    learningRecommendations: [
      'Add automated tests and CI/CD pipelines to top repositories to demonstrate production readiness',
      'Write clearer README files with setup instructions and screenshots to improve repo health scores',
      `Explore adjacent technologies to ${languageStats.primaryLanguage} to broaden the technology stack`,
    ],
    recommendedProjects: [
      'A full-stack project with authentication, tests, and CI/CD to showcase end-to-end skills',
      'An open-source contribution to a popular repository in your primary language',
      'A small developer tool or CLI utility solving a real problem you have encountered',
    ],
    resumeSummary: `${profile.name || profile.username} is a ${experienceLevel.toLowerCase()} software developer specializing in ${languageStats.primaryLanguage}, with a public GitHub portfolio of ${repoStats.originalRepos} projects and ${repoStats.totalStars} stars demonstrating hands-on experience across ${languageStats.totalLanguages} languages.`,
    careerRecommendations: [
      `${languageStats.primaryLanguage} Developer roles matching current project focus`,
      'Open-source contributor / maintainer track to grow visibility and network',
    ],
  };
}

async function generateInsights(analysis) {
  const provider = (process.env.AI_PROVIDER || '').toLowerCase();

  try {
    if (provider === 'openai' && process.env.OPENAI_API_KEY) {
      const prompt = buildPrompt(analysis);
      const result = await callOpenAI(prompt);
      return { ...result, source: 'openai' };
    }
    if (provider === 'gemini' && process.env.GEMINI_API_KEY) {
      const prompt = buildPrompt(analysis);
      const result = await callGemini(prompt);
      return { ...result, source: 'gemini' };
    }
  } catch (err) {
    console.error('AI provider call failed, falling back to rule-based insights:', err.message);
  }

  return { ...generateFallbackInsights(analysis), source: 'rule-based' };
}

module.exports = { generateInsights };
