const axios = require('axios');
const NodeCache = require('node-cache');

// Cache GitHub responses for 5 minutes to reduce API calls & speed up repeat lookups
const cache = new NodeCache({ stdTTL: 300 });

const github = axios.create({
  baseURL: 'https://api.github.com',
  headers: {
    Accept: 'application/vnd.github+json',
    'X-GitHub-Api-Version': '2022-11-28',
    ...(process.env.GITHUB_TOKEN ? { Authorization: `Bearer ${process.env.GITHUB_TOKEN}` } : {}),
  },
  timeout: 15000,
});

async function cached(key, fn) {
  const hit = cache.get(key);
  if (hit) return hit;
  const value = await fn();
  cache.set(key, value);
  return value;
}

async function getUser(username) {
  return cached(`user:${username}`, async () => {
    const { data } = await github.get(`/users/${username}`);
    return data;
  });
}

async function getAllRepos(username) {
  return cached(`repos:${username}`, async () => {
    let page = 1;
    let all = [];
    while (true) {
      const { data } = await github.get(`/users/${username}/repos`, {
        params: { per_page: 100, page, sort: 'updated' },
      });
      all = all.concat(data);
      if (data.length < 100 || page > 10) break; // safety cap at 1000 repos
      page += 1;
    }
    return all;
  });
}

// Byte-accurate language breakdown for a repo (GitHub /languages endpoint)
async function getRepoLanguages(owner, repo) {
  return cached(`langs:${owner}/${repo}`, async () => {
    try {
      const { data } = await github.get(`/repos/${owner}/${repo}/languages`);
      return data;
    } catch {
      return {};
    }
  });
}

async function getReadme(owner, repo) {
  return cached(`readme:${owner}/${repo}`, async () => {
    try {
      const { data } = await github.get(`/repos/${owner}/${repo}/readme`);
      return data;
    } catch {
      return null;
    }
  });
}

async function getEvents(username) {
  return cached(`events:${username}`, async () => {
    try {
      const { data } = await github.get(`/users/${username}/events/public`, {
        params: { per_page: 100 },
      });
      return data;
    } catch {
      return [];
    }
  });
}

async function searchTrendingRepos(language = '', since = '') {
  const cacheKey = `trending:${language}:${since}`;
  return cached(cacheKey, async () => {
    const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    let q = `created:>${oneWeekAgo}`;
    if (language) q += ` language:${language}`;
    const { data } = await github.get('/search/repositories', {
      params: { q, sort: 'stars', order: 'desc', per_page: 15 },
    });
    return data.items;
  });
}

module.exports = {
  getUser,
  getAllRepos,
  getRepoLanguages,
  getReadme,
  getEvents,
  searchTrendingRepos,
};
