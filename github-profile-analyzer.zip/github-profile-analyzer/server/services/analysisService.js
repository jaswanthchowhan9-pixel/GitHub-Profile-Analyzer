const githubService = require('./githubService');

// Repos to fetch byte-accurate language data for (keeps request count sane on huge accounts)
const MAX_REPOS_FOR_LANGUAGE_BYTES = 25;

function safeDate(d) {
  return d ? new Date(d) : null;
}

async function computeLanguageStats(username, repos) {
  const nonForkRepos = repos.filter((r) => !r.fork);
  const topRepos = [...nonForkRepos]
    .sort((a, b) => (b.stargazers_count || 0) - (a.stargazers_count || 0))
    .slice(0, MAX_REPOS_FOR_LANGUAGE_BYTES);

  const languageBytes = {};

  await Promise.all(
    topRepos.map(async (repo) => {
      const langs = await githubService.getRepoLanguages(username, repo.name);
      Object.entries(langs).forEach(([lang, bytes]) => {
        languageBytes[lang] = (languageBytes[lang] || 0) + bytes;
      });
    })
  );

  // Fallback: for repos outside the top slice, count by primary `language` field
  nonForkRepos.slice(MAX_REPOS_FOR_LANGUAGE_BYTES).forEach((repo) => {
    if (repo.language) {
      languageBytes[repo.language] = (languageBytes[repo.language] || 0) + 1000; // nominal weight
    }
  });

  const totalBytes = Object.values(languageBytes).reduce((a, b) => a + b, 0) || 1;

  const distribution = Object.entries(languageBytes)
    .map(([language, bytes]) => ({
      language,
      bytes,
      percentage: Number(((bytes / totalBytes) * 100).toFixed(2)),
    }))
    .sort((a, b) => b.bytes - a.bytes);

  return {
    distribution,
    primaryLanguage: distribution[0] ? distribution[0].language : 'N/A',
    totalLanguages: distribution.length,
  };
}

function computeRepoStats(repos) {
  const nonForkRepos = repos.filter((r) => !r.fork);

  const mostStarred = [...repos].sort((a, b) => b.stargazers_count - a.stargazers_count)[0] || null;
  const mostForked = [...repos].sort((a, b) => b.forks_count - a.forks_count)[0] || null;

  const totalStars = repos.reduce((sum, r) => sum + (r.stargazers_count || 0), 0);
  const totalForks = repos.reduce((sum, r) => sum + (r.forks_count || 0), 0);
  const totalOpenIssues = repos.reduce((sum, r) => sum + (r.open_issues_count || 0), 0);
  const totalWatchers = repos.reduce((sum, r) => sum + (r.watchers_count || 0), 0);
  const totalSizeKb = repos.reduce((sum, r) => sum + (r.size || 0), 0);

  const topics = new Set();
  repos.forEach((r) => (r.topics || []).forEach((t) => topics.add(t)));

  const licenses = {};
  repos.forEach((r) => {
    const key = r.license ? r.license.spdx_id : 'None';
    licenses[key] = (licenses[key] || 0) + 1;
  });

  return {
    totalRepos: repos.length,
    originalRepos: nonForkRepos.length,
    forkedRepos: repos.length - nonForkRepos.length,
    totalStars,
    totalForks,
    totalOpenIssues,
    totalWatchers,
    totalSizeKb,
    mostStarred: mostStarred && mostStarred.stargazers_count > 0 ? summarizeRepo(mostStarred) : null,
    mostForked: mostForked && mostForked.forks_count > 0 ? summarizeRepo(mostForked) : null,
    topics: Array.from(topics).slice(0, 30),
    licenses,
  };
}

function summarizeRepo(r) {
  return {
    name: r.name,
    full_name: r.full_name,
    description: r.description,
    html_url: r.html_url,
    stargazers_count: r.stargazers_count,
    forks_count: r.forks_count,
    language: r.language,
    open_issues_count: r.open_issues_count,
    watchers_count: r.watchers_count,
    size: r.size,
    topics: r.topics || [],
    created_at: r.created_at,
    updated_at: r.updated_at,
    pushed_at: r.pushed_at,
    fork: r.fork,
    license: r.license ? r.license.spdx_id : null,
    archived: r.archived,
    default_branch: r.default_branch,
  };
}

function computeContributionTimeline(repos) {
  const byYear = {};
  repos.forEach((r) => {
    const year = new Date(r.created_at).getFullYear();
    byYear[year] = (byYear[year] || 0) + 1;
  });

  const timeline = Object.entries(byYear)
    .map(([year, count]) => ({ year: Number(year), reposCreated: count }))
    .sort((a, b) => a.year - b.year);

  // Recent activity: repos pushed to in the last 90 days
  const ninetyDaysAgo = Date.now() - 90 * 24 * 60 * 60 * 1000;
  const recentlyActive = repos.filter((r) => new Date(r.pushed_at).getTime() > ninetyDaysAgo).length;

  return { timeline, recentlyActiveRepos: recentlyActive };
}

function computeEventActivity(events) {
  const typeCounts = {};
  const byDay = {};

  events.forEach((e) => {
    typeCounts[e.type] = (typeCounts[e.type] || 0) + 1;
    const day = e.created_at.split('T')[0];
    byDay[day] = (byDay[day] || 0) + 1;
  });

  const heatmap = Object.entries(byDay)
    .map(([date, count]) => ({ date, count }))
    .sort((a, b) => (a.date > b.date ? 1 : -1));

  return { typeCounts, heatmap, totalPublicEvents: events.length };
}

function repoHealthScore(repo) {
  let score = 0;
  if (repo.description) score += 15;
  if (repo.license) score += 15;
  if ((repo.topics || []).length > 0) score += 10;
  if (repo.has_wiki) score += 5;
  const daysSincePush = (Date.now() - new Date(repo.pushed_at).getTime()) / (1000 * 60 * 60 * 24);
  if (daysSincePush < 180) score += 25;
  else if (daysSincePush < 365) score += 10;
  if (repo.open_issues_count === 0) score += 10;
  if (!repo.archived) score += 10;
  if (repo.stargazers_count > 0) score += 10;
  return Math.min(100, score);
}

function computeDeveloperScore({ user, repoStats, languageStats, contribution }) {
  let score = 0;

  // Followers & network (max 20)
  score += Math.min(20, Math.log2((user.followers || 0) + 1) * 4);

  // Stars earned (max 25)
  score += Math.min(25, Math.log2((repoStats.totalStars || 0) + 1) * 4);

  // Repo output & consistency (max 20)
  score += Math.min(20, Math.log2((repoStats.originalRepos || 0) + 1) * 5);

  // Language diversity (max 15)
  score += Math.min(15, languageStats.totalLanguages * 1.5);

  // Recent activity (max 20)
  score += Math.min(20, contribution.recentlyActiveRepos * 2.5);

  return Math.round(Math.min(100, score));
}

function estimateExperienceLevel({ user, repoStats, developerScore }) {
  const accountAgeYears = (Date.now() - new Date(user.created_at).getTime()) / (1000 * 60 * 60 * 24 * 365);

  if (developerScore >= 75 && accountAgeYears >= 3) return 'Senior / Advanced';
  if (developerScore >= 50 || accountAgeYears >= 2) return 'Intermediate';
  if (developerScore >= 25 || accountAgeYears >= 0.5) return 'Junior / Growing';
  return 'Beginner';
}

async function analyzeProfile(username) {
  const [user, repos, events] = await Promise.all([
    githubService.getUser(username),
    githubService.getAllRepos(username),
    githubService.getEvents(username),
  ]);

  const languageStats = await computeLanguageStats(username, repos);
  const repoStats = computeRepoStats(repos);
  const contribution = computeContributionTimeline(repos);
  const eventActivity = computeEventActivity(events);

  const developerScore = computeDeveloperScore({ user, repoStats, languageStats, contribution });
  const experienceLevel = estimateExperienceLevel({ user, repoStats, developerScore });

  const reposWithHealth = repos
    .filter((r) => !r.fork)
    .map((r) => ({ name: r.name, healthScore: repoHealthScore(r) }))
    .sort((a, b) => b.healthScore - a.healthScore);

  const avgRepoHealth = reposWithHealth.length
    ? Math.round(reposWithHealth.reduce((s, r) => s + r.healthScore, 0) / reposWithHealth.length)
    : 0;

  return {
    profile: {
      username: user.login,
      name: user.name,
      avatar_url: user.avatar_url,
      bio: user.bio,
      company: user.company,
      location: user.location,
      blog: user.blog,
      twitter_username: user.twitter_username,
      email: user.email,
      followers: user.followers,
      following: user.following,
      public_repos: user.public_repos,
      public_gists: user.public_gists,
      created_at: user.created_at,
      html_url: user.html_url,
      hireable: user.hireable,
    },
    repoStats,
    languageStats,
    contribution,
    eventActivity,
    repoHealth: { average: avgRepoHealth, top: reposWithHealth.slice(0, 5) },
    developerScore,
    experienceLevel,
    repos: repos.map(summarizeRepo),
  };
}

module.exports = {
  analyzeProfile,
  computeLanguageStats,
  computeRepoStats,
  summarizeRepo,
};
