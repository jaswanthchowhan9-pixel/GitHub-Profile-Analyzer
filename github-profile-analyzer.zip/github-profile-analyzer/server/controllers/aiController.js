const aiService = require('../services/aiService');
const analysisService = require('../services/analysisService');

// Accepts either a raw `analysis` object in the body, or a `username` to analyze fresh.
async function getInsights(req, res, next) {
  try {
    let analysis = req.body.analysis;
    if (!analysis && req.body.username) {
      analysis = await analysisService.analyzeProfile(req.body.username);
    }
    if (!analysis) {
      return res.status(400).json({ error: 'Provide either "analysis" or "username" in the request body.' });
    }
    const insights = await aiService.generateInsights(analysis);
    res.json(insights);
  } catch (err) {
    next(err);
  }
}

module.exports = { getInsights };
