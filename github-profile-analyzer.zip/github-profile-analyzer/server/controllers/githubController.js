const githubService = require('../services/githubService');
const analysisService = require('../services/analysisService');

async function getProfile(req, res, next) {
  try {
    const user = await githubService.getUser(req.params.username);
    res.json(user);
  } catch (err) {
    next(err);
  }
}

async function getRepos(req, res, next) {
  try {
    const repos = await githubService.getAllRepos(req.params.username);
    res.json(repos.map(analysisService.summarizeRepo));
  } catch (err) {
    next(err);
  }
}

async function getAnalysis(req, res, next) {
  try {
    const analysis = await analysisService.analyzeProfile(req.params.username);
    res.json(analysis);
  } catch (err) {
    next(err);
  }
}

async function compareProfiles(req, res, next) {
  try {
    const { user1, user2 } = req.query;
    if (!user1 || !user2) {
      return res.status(400).json({ error: 'Both user1 and user2 query params are required.' });
    }
    const [a, b] = await Promise.all([
      analysisService.analyzeProfile(user1),
      analysisService.analyzeProfile(user2),
    ]);
    res.json({ user1: a, user2: b });
  } catch (err) {
    next(err);
  }
}

async function getTrending(req, res, next) {
  try {
    const { language } = req.query;
    const repos = await githubService.searchTrendingRepos(language || '');
    res.json(repos);
  } catch (err) {
    next(err);
  }
}

module.exports = { getProfile, getRepos, getAnalysis, compareProfiles, getTrending };
