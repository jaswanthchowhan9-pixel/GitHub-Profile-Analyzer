const express = require('express');
const axios = require('axios');
const router = express.Router();

// Optional GitHub OAuth login flow.
// Requires GITHUB_OAUTH_CLIENT_ID / GITHUB_OAUTH_CLIENT_SECRET / GITHUB_OAUTH_CALLBACK_URL in .env
// If not configured, these routes return a clear error instead of crashing the server.

router.get('/github', (req, res) => {
  const clientId = process.env.GITHUB_OAUTH_CLIENT_ID;
  const callbackUrl = process.env.GITHUB_OAUTH_CALLBACK_URL;
  if (!clientId) {
    return res.status(501).json({ error: 'GitHub OAuth is not configured on this server.' });
  }
  const redirectUrl = `https://github.com/login/oauth/authorize?client_id=${clientId}&redirect_uri=${encodeURIComponent(
    callbackUrl
  )}&scope=read:user`;
  res.redirect(redirectUrl);
});

router.get('/github/callback', async (req, res) => {
  const { code } = req.query;
  const clientId = process.env.GITHUB_OAUTH_CLIENT_ID;
  const clientSecret = process.env.GITHUB_OAUTH_CLIENT_SECRET;

  if (!clientId || !clientSecret) {
    return res.status(501).json({ error: 'GitHub OAuth is not configured on this server.' });
  }

  try {
    const tokenRes = await axios.post(
      'https://github.com/login/oauth/access_token',
      { client_id: clientId, client_secret: clientSecret, code },
      { headers: { Accept: 'application/json' } }
    );

    const accessToken = tokenRes.data.access_token;
    if (!accessToken) {
      return res.status(400).json({ error: 'Failed to obtain access token from GitHub.' });
    }

    const userRes = await axios.get('https://api.github.com/user', {
      headers: { Authorization: `Bearer ${accessToken}` },
    });

    // In a production app, issue your own signed session/JWT cookie here instead
    // of redirecting the raw token to the client.
    const clientUrl = process.env.CLIENT_URL || 'http://localhost:5173';
    res.redirect(`${clientUrl}/dashboard/${userRes.data.login}?authed=true`);
  } catch (err) {
    res.status(500).json({ error: 'GitHub OAuth callback failed.', details: err.message });
  }
});

module.exports = router;
