const express = require('express');
const router = express.Router();
const githubController = require('../controllers/githubController');

router.get('/trending', githubController.getTrending);
router.get('/compare', githubController.compareProfiles);
router.get('/profile/:username', githubController.getProfile);
router.get('/repos/:username', githubController.getRepos);
router.get('/analysis/:username', githubController.getAnalysis);

module.exports = router;
